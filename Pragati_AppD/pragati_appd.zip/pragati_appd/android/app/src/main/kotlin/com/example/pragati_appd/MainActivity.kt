package com.example.pragati_appd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
